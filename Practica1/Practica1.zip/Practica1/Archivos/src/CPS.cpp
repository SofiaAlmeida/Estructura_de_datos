#include <iostream>
#include <ctime>

using namespace std;

int main () {
	cout << CLOCKS_PER_SEC;
}
